An implementation of movement \#27 from ["501 Mechanical Movements"](http://books.google.de/books/about/507_Mechanical_Movements.html?id=CSH5UgzD8oIC&redir_esc=y) by Henry T. Brown.

**This is still a work in progress.**

***

##### Instructions

* Attach three 623ZZ bearings to the small wheel with short M3 bolts or screws
* Connect the small and large wheel to the frame with an M4 and M5 bolt respectively.
(Note: So far the wheels have been printed and tested, but not yet the frame.)
